//
//  TYTableSuspendFooterView.m
//  UITableViewFooter
//
//  Created by Tory on 2020/11/5.
//

#import "TYTableSuspendFooterView.h"

@interface TYTableSuspendFooterView ()

@property (nonatomic, assign) CGSize lastContentSize;

@end

@implementation TYTableSuspendFooterView

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style
{
    self = [super initWithFrame:frame style:style];
    if (self) {
        [self addObserver];
    }
    return self;
}

- (void)addObserver {
    [self addObserver:self forKeyPath:@"contentOffset" options:(NSKeyValueObservingOptionNew) context:nil];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    //    NSLog(@"self.contentOffset = %@", NSStringFromCGPoint(self.contentOffset));

    if (CGSizeEqualToSize(self.lastContentSize, self.contentSize)) {
        return;
    }
    
    NSLog(@"[layout subviews] reset footer frame");
    
    self.lastContentSize = self.contentSize;
    
    [self addSubview:self.suspendFooter];
    UIEdgeInsets inset = self.contentInset;
    
    CGFloat totalHeight = self.contentSize.height + CGRectGetHeight(self.suspendFooter.frame);
    if (totalHeight > CGRectGetHeight(self.frame)) {
        self.suspendFooter.frame = CGRectMake(0, self.contentSize.height, CGRectGetWidth(self.frame), CGRectGetHeight(self.suspendFooter.frame));
        
        self.contentInset = UIEdgeInsetsMake(inset.top, inset.left, CGRectGetHeight(self.suspendFooter.frame), inset.right);
    } else {
        self.suspendFooter.frame = CGRectMake(0, CGRectGetHeight(self.frame) - CGRectGetHeight(self.suspendFooter.frame), CGRectGetWidth(self.frame), CGRectGetHeight(self.suspendFooter.frame));
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    [self contentOffsetYDidChange];
}
 
- (void)contentOffsetYDidChange {
    CGFloat totalHeight = self.contentSize.height + CGRectGetHeight(self.suspendFooter.frame);
    if (totalHeight > CGRectGetHeight(self.frame)) {
        
        CGFloat offset =  self.contentOffset.y + CGRectGetHeight(self.frame) - self.contentSize.height - CGRectGetHeight(self.suspendFooter.frame);
        if (offset >= 0.f) {
            self.suspendFooter.frame = CGRectMake(0, self.contentSize.height + offset, CGRectGetWidth(self.frame), CGRectGetHeight(self.suspendFooter.frame));
        }
    } else {
        CGFloat offset = self.contentOffset.y;
        self.suspendFooter.frame = CGRectMake(0, CGRectGetHeight(self.frame) - CGRectGetHeight(self.suspendFooter.frame) + offset, CGRectGetWidth(self.frame), CGRectGetHeight(self.suspendFooter.frame));
    }
}

@end
