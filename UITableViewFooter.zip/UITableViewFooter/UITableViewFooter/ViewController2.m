//
//  ViewController2.m
//  UITableViewFooter
//
//  Created by Tory on 2020/11/6.
//

#import "ViewController2.h"
#import "TYTableSuspendFooterView.h"
#import "ViewController.h"

#define MAX_CELL_COUNT 13

@interface ViewController2 ()

@property (nonatomic, strong) TYTableSuspendFooterView *tableView;

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"test";
 
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"跳转" style:UIBarButtonItemStyleDone target:self action:@selector(jumpAction)];
    
    [self setTableViw];
}

- (void)jumpAction {
    [self.navigationController pushViewController:[ViewController new] animated:YES];
}

- (void)setTableViw {
    self.view.backgroundColor = UIColor.grayColor;
    self.tableView = [[TYTableSuspendFooterView alloc] init];
    self.tableView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 64);
    
    UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 80)];
    footer.backgroundColor = UIColor.orangeColor;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jumpAction)];
    [footer addGestureRecognizer:tap];
    self.tableView.suspendFooter = footer;
    self.tableView.backgroundColor = UIColor.blueColor;
    
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;

}

#pragma mark UITableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return MAX_CELL_COUNT;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"CLTableCell";

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];

    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.textLabel.textColor = [UIColor whiteColor];
    }

    if (indexPath.section < MAX_CELL_COUNT) {
        cell.textLabel.text = [NSString stringWithFormat:@"Cell #%d", indexPath.section];
    } else {
        cell.textLabel.text = @"";
    }
    cell.textLabel.backgroundColor = UIColor.greenColor;

    return cell;
}


@end
