//
//  AppDelegate.h
//  UITableViewFooter
//
//  Created by Tory on 2020/11/5.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

