//
//  ViewController.swift
//  GodEyeDemo
//
//  Created by Tory on 2020/8/16.
//  Copyright © 2020 Tory. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

